import{a as t}from"../chunks/entry.Dgo2YOqG.js";export{t as start};
